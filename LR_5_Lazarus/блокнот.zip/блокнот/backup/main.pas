unit Main;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls;

type

  { TfMain }

  TfMain = class(TForm)
    bSave: TButton;
    bRead: TButton;
    bClear: TButton;
    Memo1: TMemo;
    ScrollBar1: TScrollBar;
    procedure bClearClick(Sender: TObject);
    procedure bReadClick(Sender: TObject);
    procedure bSaveClick(Sender: TObject);
    procedure Memo1Click(Sender: TObject);
    procedure ScrollBar1Change(Sender: TObject);
  private

  public

  end;

var
  fMain: TfMain;

implementation

{$R *.lfm}

{ TfMain }

procedure TfMain.bSaveClick(Sender: TObject);
begin
  Memo1.Lines.SaveToFile('MyText.txt');
end;

procedure TfMain.Memo1Click(Sender: TObject);
begin

end;

procedure TfMain.ScrollBar1Change(Sender: TObject);
begin

end;

procedure TfMain.bClearClick(Sender: TObject);
begin
  Memo1.Lines.Clear;
end;

procedure TfMain.bReadClick(Sender: TObject);
begin
  begin
  if FileExists('MyText.txt') then
    Memo1.Lines.LoadFromFile('MyText.txt')
  else ShowMessage('Файл MyText.txt не существует');
end;

end;


end.

