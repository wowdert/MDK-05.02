unit Main;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls;

type

  { TfMain }

  TfMain = class(TForm)
    Button1: TButton;
    ComboBox1: TComboBox;
    Edit1: TEdit;
    ListBox1: TListBox;
    procedure Button1ChangeBounds(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure ComboBox1Change(Sender: TObject);
    procedure Edit1Change(Sender: TObject);
  private

  public

  end;

var
  fMain: TfMain;

implementation

{$R *.lfm}

{ TfMain }

procedure TfMain.Button1ChangeBounds(Sender: TObject);
begin

end;

procedure TfMain.Button1Click(Sender: TObject);
  var
    i: integer; //счетчик
  begin
    //очистим ComboBox:
    ComboBox1.Clear;
    //далее в цикле обходим весь ListBox, и если строка
    //выделена - копируем ее в ComboBox:
    for i:= 0 to ListBox1.Count -1 do
      if ListBox1.Selected[i] then
        ComboBox1.Items.Add(ListBox1.Items.Strings[i]);
    //если ComboBox не пустой, выделим первый элемент, иначе
    //не выделяем ничего:
    if ComboBox1.Items.Count > 0 then begin
      ComboBox1.ItemIndex:= 0;
      //копируем в Edit1 выделенную строку из ComboBox:
      Edit1.Text:= ComboBox1.Items.Strings[ComboBox1.ItemIndex];
    end
    else ComboBox1.ItemIndex:= -1;
  end;

procedure TfMain.Edit1Change(Sender: TObject);
begin

end;

procedure TfMain.ComboBox1Change(Sender: TObject);
begin
  //копируем в Edit1 выделенную строку из ComboBox:
  Edit1.Text:= ComboBox1.Items.Strings[ComboBox1.ItemIndex];
end;

end.

