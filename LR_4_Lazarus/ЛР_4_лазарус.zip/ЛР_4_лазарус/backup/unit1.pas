unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, Buttons, Math;

type
  { TForm1 }
  TForm1 = class(TForm)
    TheInputField: TMemo;
    one, two, three, four, five, six, seven, eight, nine, zero: TBitBtn;
    plus, minus, multiply, devision, equally: TBitBtn;
    back, root, square, fraction, point: TBitBtn;
    clearFullNumbers, clearOneNumber: TBitBtn;

    procedure FormCreate(Sender: TObject);
    procedure DigitClick(Sender: TObject);
    procedure OperationClick(Sender: TObject);
    procedure EqualClick(Sender: TObject);
    procedure clearFullNumbersClick(Sender: TObject);
    procedure clearOneNumberClick(Sender: TObject);
    procedure pointClick(Sender: TObject);
    procedure rootClick(Sender: TObject);
    procedure squareClick(Sender: TObject);
    procedure fractionClick(Sender: TObject);
    procedure backClick(Sender: TObject);

  private
    Operand1: Double;
    Operation: Char;
    IsNewNumber: Boolean;
    FCurrentEntry: string;
    FIsError: Boolean; // Флаг блокировки при ошибке
    procedure UpdateDisplay;
    procedure ProcessResult(Res: Double);
    procedure TriggerError(Msg: string); // Метод для активации блокировки
  public
  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

{ Вспомогательные методы }

procedure TForm1.UpdateDisplay;
begin
  TheInputField.Text := FCurrentEntry;
end;

procedure TForm1.TriggerError(Msg: string);
begin
  ShowMessage(Msg);
  FCurrentEntry := 'Ошибка';
  FIsError := True; // Включаем блокировку
  UpdateDisplay;
end;

procedure TForm1.ProcessResult(Res: Double);
begin
  // Проверка на математическую бесконечность или лимит e150
  if IsInfinite(Res) or IsNaN(Res) or (Abs(Res) > 1e150) then
  begin
    TriggerError('Ошибка: Лимит символов после экспоненты!  нажмите ce для продолжения');
    Exit;
  end;

  FCurrentEntry := FloatToStr(Res);
  IsNewNumber := True;
  UpdateDisplay;
end;

{ Обработчики событий }

procedure TForm1.FormCreate(Sender: TObject);
begin
  DefaultFormatSettings.DecimalSeparator := '.';
  FCurrentEntry := '0';
  Operand1 := 0;
  Operation := #0;
  IsNewNumber := True;
  FIsError := False;
  UpdateDisplay;
end;

procedure TForm1.DigitClick(Sender: TObject);
var Digit: string;
begin
  if FIsError then Exit; // Блокировка

  Digit := (Sender as TBitBtn).Caption;
  if (not IsNewNumber) and (Length(FCurrentEntry) >= 15) then Exit;

  if IsNewNumber then
  begin
    if FCurrentEntry = '-' then FCurrentEntry := '-' + Digit
    else FCurrentEntry := Digit;
    IsNewNumber := False;
  end
  else
  begin
    if FCurrentEntry = '0' then FCurrentEntry := Digit
    else FCurrentEntry := FCurrentEntry + Digit;
  end;
  UpdateDisplay;
end;

procedure TForm1.OperationClick(Sender: TObject);
var OpText: string;
begin
  if FIsError then Exit; // Блокировка

  OpText := (Sender as TBitBtn).Caption;

  if OpText = '-' then
  begin
    if IsNewNumber or (FCurrentEntry = '0') then
    begin
      if FCurrentEntry = '-' then FCurrentEntry := '0'
      else FCurrentEntry := '-';
      IsNewNumber := False;
      UpdateDisplay;
      Exit;
    end;
  end;

  if (Operation <> #0) and (not IsNewNumber) then EqualClick(Sender);

  Operand1 := StrToFloatDef(FCurrentEntry, 0);
  Operation := OpText[1];
  IsNewNumber := True;
end;

procedure TForm1.EqualClick(Sender: TObject);
var Operand2, Res: Double;
begin
  if FIsError or (Operation = #0) then Exit;

  if FCurrentEntry = '-' then FCurrentEntry := '0';
  Operand2 := StrToFloatDef(FCurrentEntry, 0);

  case Operation of
    '+': Res := Operand1 + Operand2;
    '-': Res := Operand1 - Operand2;
    '*': Res := Operand1 * Operand2;
    '/':
      begin
        if Operand2 = 0 then
        begin
          TriggerError('Деление на ноль невозможно! нажмите ce для продолжения');
          Exit;
        end;
        Res := Operand1 / Operand2;
      end;
  else Exit;
  end;

  Operation := #0;
  ProcessResult(Res);
end;

procedure TForm1.backClick(Sender: TObject);
begin
  if FIsError then Exit;

  if Pos('E', UpperCase(FCurrentEntry)) > 0 then
  begin
    ShowMessage('Используйте C для сброса экспоненты.');
    Exit;
  end;

  if Length(FCurrentEntry) > 1 then
  begin
    Delete(FCurrentEntry, Length(FCurrentEntry), 1);
    if FCurrentEntry = '-' then FCurrentEntry := '0';
  end
  else FCurrentEntry := '0';
  UpdateDisplay;
end;

procedure TForm1.clearFullNumbersClick(Sender: TObject);
begin
  // Единственная кнопка (CE), работающая при ошибке
  FCurrentEntry := '0';
  Operation := #0;
  Operand1 := 0;
  IsNewNumber := True;
  FIsError := False; // Сброс блокировки
  UpdateDisplay;
end;

procedure TForm1.clearOneNumberClick(Sender: TObject);
begin
  if FIsError then Exit;
  FCurrentEntry := '0';
  IsNewNumber := True;
  UpdateDisplay;
end;

procedure TForm1.pointClick(Sender: TObject);
begin
  if FIsError then Exit;
  if IsNewNumber then
  begin
    FCurrentEntry := '0.';
    IsNewNumber := False;
  end
  else if Pos('.', FCurrentEntry) = 0 then
    FCurrentEntry := FCurrentEntry + '.';
  UpdateDisplay;
end;

procedure TForm1.rootClick(Sender: TObject);
var v: Double;
begin
  if FIsError then Exit;
  v := StrToFloatDef(FCurrentEntry, 0);
  if v < 0 then TriggerError('Корень из отрицательного числа! нажмите ce для продолжения')
  else ProcessResult(Sqrt(v));
end;

procedure TForm1.squareClick(Sender: TObject);
begin
  if FIsError then Exit;
  ProcessResult(Sqr(StrToFloatDef(FCurrentEntry, 0)));
end;

procedure TForm1.fractionClick(Sender: TObject);
var v: Double;
begin
  if FIsError then Exit;
  v := StrToFloatDef(FCurrentEntry, 0);
  if v = 0 then TriggerError('Деление на ноль! нажмите ce для продолжения')
  else ProcessResult(1/v);
end;

end.
