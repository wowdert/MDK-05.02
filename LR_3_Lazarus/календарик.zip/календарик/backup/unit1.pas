unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, Calendar, EditBtn,
  StdCtrls;

type

  { TForm1 }

  TForm1 = class(TForm)
    Button1: TButton;
    Calendar1: TCalendar;
    DateEdit1: TDateEdit;
    procedure Button1Click(Sender: TObject);
    procedure DateEdit1Change(Sender: TObject);
  private

  public

  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

{ TForm1 }

procedure TForm1.DateEdit1Change(Sender: TObject);
begin

end;

procedure TForm1.Button1Click(Sender: TObject);
var
  dt: TDateTime;
  s: String;
  Year, Month, Day: Word;
begin
  // 1. Демонстрация функции Date, Time и Now через DateTimeToStr
  dt := Date; // Получили текущую дату
  dt := Time; // Получили текущее время
  ShowMessage(DateTimeToStr(Now)); // Вывод текущих даты и времени


  // 2. Изменение системной переменной формата даты (из файла)
  ShortDateFormat := 'dd.mm.yy';


  // 3. Функция FormatDateTime и конвертация через SysToUTF8
  s := FormatDateTime('dd mmmm yyyy - hh:nn:ss', Now);


  // 4. Процедура DateTimeToString и вывод дня недели длинным форматом 'dddddd'
  DateTimeToString(s, 'dddddd', Now);
  ShowMessage + #13 + FormattedStrs;


  // 5. Функция DayOfWeek и вывод названия дня недели через оператор case
  case DayOfWeek(Now) of
    1: s := 'Воскресение';
    2: s := 'Понедельник';
    3: s := 'Вторник';
    4: s := 'Среда';
    5: s := 'Четверг';
    6: s := 'Пятница';
    7: s := 'Суббота';
  end;
  ShowMessage('Сегодня ' + FormatDateTime('ddddd', Now) + ', ' + s);


  // 6. Процедура DecodeDate (Разбиение даты на числа)
  DecodeDate(Now, Year, Month, Day);
  ShowMessage('Год - ' + IntToStr(Year) + #13 +
              'Месяц - ' + IntToStr(Month) + #13 +
              'День - ' + IntToStr(Day));


  // 7. Функция EncodeDate (Сборка даты из чисел)
  Year := 1999;
  Month := 3;
  Day := 9;
  dt := EncodeDate(Year, Month, Day);
  ShowMessage('Указали ' + FormatDateTime('dddddd', dt));


  // 8. Функция IsLeapYear (Проверка на високосный год)
  Year := 1917;
  if IsLeapYear(Year) then
    ShowMessage('Указан високосный год')
  else
    ShowMessage('Указан невисокосный год');


  // 9. Функция StrToDateTime
  dt := StrToDateTime('21.10.2013 14:25:30');
  ShowMessage('Указали ' + FormatDateTime('c', dt));
end;
end.

