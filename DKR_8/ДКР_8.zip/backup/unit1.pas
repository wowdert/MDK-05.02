unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls;

type

  { TForm1 }

  TForm1 = class(TForm)
    btnClac: TButton;
    btnClear: TButton;
    cbMaterial: TComboBox;
    edLength: TEdit;
    edWidth: TEdit;
    edHeight: TEdit;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Label4: TLabel;
    Memo1: TMemo;
    procedure btnClacClick(Sender: TObject);
    procedure btnClearClick(Sender: TObject);
    procedure cbMaterialChange(Sender: TObject);
    procedure edHeightKeyPress(Sender: TObject; var Key: char);
    procedure edLengthKeyPress(Sender: TObject; var Key: char);
    procedure edWidthKeyPress(Sender: TObject; var Key: char);
    procedure FormCreate(Sender: TObject);
  private

  public

  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

{ TForm1 }

procedure TForm1.FormCreate(Sender: TObject);
begin
  Constraints.MinWidth := 734;
Constraints.MinHeight := 430;

cbMaterial.Items.Add('Сосна');
cbMaterial.Items.Add('Ель');
cbMaterial.Items.Add('Дуб');
cbMaterial.Items.Add('Берёза');
cbMaterial.Items.Add('Бук');
cbMaterial.Items.Add('Лиственница');
cbMaterial.Items.Add('Алюминий');
cbMaterial.Items.Add('Сталь');
cbMaterial.Items.Add('Медь');
cbMaterial.Items.Add('Свинец');

cbMaterial.ItemIndex := 0;

Memo1.Lines.Add('Введите данные и нажмите "Рассчитать".');
end;

procedure TForm1.cbMaterialChange(Sender: TObject);
begin

end;

procedure TForm1.btnClacClick(Sender: TObject);
  const
  Density: array[0..9] of Double =
  (520, 450, 700, 650, 720, 660, 2700, 7850, 8900, 11340);

var
  L, W, H, V, M: Double;

begin

  if (Trim(edLength.Text) = '') or
     (Trim(edWidth.Text) = '') or
     (Trim(edHeight.Text) = '') then
  begin
    ShowMessage('Заполните все поля!');
    Exit;
  end;

  L := StrToFloat(edLength.Text);
  W := StrToFloat(edWidth.Text);
  H := StrToFloat(edHeight.Text);

  V := L * W * H;
  M := V * Density[cbMaterial.ItemIndex];

  Memo1.Clear;

  Memo1.Lines.Add('Материал: ' + cbMaterial.Text);
  Memo1.Lines.Add('Объём: ' +
    FloatToStrF(V, ffFixed, 8, 3) + ' м³');

  Memo1.Lines.Add('Масса: ' +
    FloatToStrF(M, ffFixed, 8, 3) + ' кг');
end;

procedure TForm1.btnClearClick(Sender: TObject);
begin
edLength.Clear;
edWidth.Clear;
edHeight.Clear;

cbMaterial.ItemIndex := 0;

Memo1.Clear;
end;

procedure TForm1.edHeightKeyPress(Sender: TObject; var Key: char);
begin
   if not (Key in ['0'..'9', ',', '.', #8]) then
    Key := #0;
end;

procedure TForm1.edLengthKeyPress(Sender: TObject; var Key: char);
begin
   if not (Key in ['0'..'9', ',', '.', #8]) then
    Key := #0;
end;

procedure TForm1.edWidthKeyPress(Sender: TObject; var Key: char);
begin
   if not (Key in ['0'..'9', ',', '.', #8]) then
    Key := #0;
end;

end.

