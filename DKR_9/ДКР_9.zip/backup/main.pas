unit Main;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, Buttons, ExtCtrls,
  StdCtrls, Grids, LazUTF8, Menus;

type
  { TForm1 }
  TForm1 = class(TForm)
    MainMenu1: TMainMenu;
    miFile, miFileNew, miFileOpen, miSave, miFileSaveas, miFileExit: TMenuItem;
    miRecord, miAdd, miEdit, miDel, miSort, miSortAsc, miSortDesc, miSearch, miClear: TMenuItem;
    odMain: TOpenDialog;
    sdMain: TSaveDialog;
    Edit1: TEdit;
    Label1, Label2, Label3, Label4, Label5: TLabel;
    eFIO, eRoom, eBlock, eData, eDataV: TEdit;
    Panel1: TPanel;
    SG: TStringGrid;
    Splitter1: TSplitter;

    procedure miFileNewClick(Sender: TObject);
    procedure miFileOpenClick(Sender: TObject);
    procedure miSaveClick(Sender: TObject);
    procedure miFileSaveasClick(Sender: TObject);
    procedure miFileExitClick(Sender: TObject);
    procedure miAddClick(Sender: TObject);
    procedure miEditClick(Sender: TObject);
    procedure miDelClick(Sender: TObject);
    procedure miSortAscClick(Sender: TObject);
    procedure miSortDescClick(Sender: TObject);
    procedure miSearchClick(Sender: TObject);
    procedure miClearClick(Sender: TObject);
    procedure FormClose(Sender: TObject; var CloseAction: TCloseAction);
    procedure FormCreate(Sender: TObject);
    procedure SGDblClick(Sender: TObject);
  private
    procedure SaveToFile(const FileName: string);
    procedure LoadFromFile(const FileName: string);
    procedure InitGridHeaders(Grid: TStringGrid);
    procedure ShowAllRows;
    procedure SwapGridRows(Row1, Row2: Integer);
  public
  end;

type
  dormitory = record
    FIO: string[100];
    Room: string[100];
    Block: string[50];
    Data: string[50];
    DataV: string[100];
  end;

var
  Form1: TForm1;
  CurrentFile: string;
  IsChanged: Boolean;

implementation

{$R *.lfm}

procedure TForm1.InitGridHeaders(Grid: TStringGrid);
begin
  Grid.Cells[0,0] := 'ФИО';
  Grid.Cells[1,0] := 'Комната в общежитии';
  Grid.Cells[2,0] := 'Блок';
  Grid.Cells[3,0] := 'Дата заселения';
  Grid.Cells[4,0] := 'Дата выселения';
  Grid.ColWidths[0] := 250;
  Grid.ColWidths[1] := 200;
  Grid.ColWidths[2] := 80;
  Grid.ColWidths[3] := 150;
  Grid.ColWidths[4] := 150;
end;

procedure TForm1.ShowAllRows;
var i: integer;
begin
  for i := 1 to SG.RowCount - 1 do
    SG.RowHeights[i] := SG.DefaultRowHeight;
end;

procedure TForm1.SwapGridRows(Row1, Row2: Integer);
var
  c: Integer;
  temp: string;
begin
  for c := 0 to SG.ColCount - 1 do
  begin
    temp := SG.Cells[c, Row1];
    SG.Cells[c, Row1] := SG.Cells[c, Row2];
    SG.Cells[c, Row2] := temp;
  end;
end;

procedure TForm1.SaveToFile(const FileName: string);
var
  DormitoryRec: dormitory;
  f: file of dormitory;
  i: integer;
begin
  if FileName = '' then Exit;
  AssignFile(f, FileName);
  try
    Rewrite(f);
    for i := 1 to SG.RowCount - 1 do
    begin
      FillChar(DormitoryRec, SizeOf(DormitoryRec), 0);
      DormitoryRec.FIO   := SG.Cells[0, i];
      DormitoryRec.Room  := SG.Cells[1, i];
      DormitoryRec.Block := SG.Cells[2, i];
      DormitoryRec.Data := SG.Cells[3, i];
      DormitoryRec.DataV:= SG.Cells[4, i];
      write(f, DormitoryRec);
    end;
    CloseFile(f);
    CurrentFile := FileName;
    IsChanged := False;
  except
    on E: Exception do
      ShowMessage('Ошибка ввода-вывода при работе с файлом! Проверьте диск или права доступа.');
  end;
end;

procedure TForm1.LoadFromFile(const FileName: string);
var
  DormitoryRec: dormitory;
  f: file of dormitory;
  FileSizeCheck: Int64;
begin
  if not FileExists(FileName) then
  begin
    if MessageDlg('Файл не найден', 'Попытка открыть несуществующий файл. Создать новый файл?',
                  mtConfirmation, [mbYes, mbNo], 0) = mrYes then
    begin
      miFileNewClick(nil);
    end;
    Exit;
  end;

  AssignFile(f, FileName);
  try
    Reset(f);

    FileSizeCheck := FileSize(f);
    if (FileSizeCheck > 0) and ((FileSizeCheck * SizeOf(dormitory)) mod SizeOf(dormitory) <> 0) then
    begin
      CloseFile(f);
      ShowMessage('Ошибка: Попытка открыть файл с некорректным форматом или поврежденную запись!');
      Exit;
    end;

    SG.RowCount := 1;
    while not Eof(f) do
    begin
      read(f, DormitoryRec);
      SG.RowCount := SG.RowCount + 1;
      SG.Cells[0, SG.RowCount-1] := DormitoryRec.FIO;
      SG.Cells[1, SG.RowCount-1] := DormitoryRec.Room;
      SG.Cells[2, SG.RowCount-1] := DormitoryRec.Block;
      SG.Cells[3, SG.RowCount-1] := DormitoryRec.Data;
      SG.Cells[4, SG.RowCount-1] := DormitoryRec.DataV;
    end;
    CloseFile(f);
    ShowAllRows;
    CurrentFile := FileName;
    IsChanged := False;
  except
    ShowMessage('Не удалось корректно прочитать файл. Возможно, он занят другим процессом.');
  end;
end;

procedure TForm1.FormCreate(Sender: TObject);
begin
  InitGridHeaders(SG);
  IsChanged := False;
  CurrentFile := ExtractFilePath(ParamStr(0)) + 'dormitory.dat';
  if FileExists(CurrentFile) then
    LoadFromFile(CurrentFile)
  else
    SaveToFile(CurrentFile);
end;

procedure TForm1.miFileNewClick(Sender: TObject);
begin
  SG.RowCount := 1;
  CurrentFile := '';
  IsChanged := False;
  miClearClick(Sender);
end;

procedure TForm1.miFileOpenClick(Sender: TObject);
begin
  if odMain.Execute then LoadFromFile(odMain.FileName);
end;

procedure TForm1.miSaveClick(Sender: TObject);
begin
  if CurrentFile <> '' then SaveToFile(CurrentFile) else miFileSaveasClick(Sender);
end;

procedure TForm1.miFileSaveasClick(Sender: TObject);
begin
  if sdMain.Execute then SaveToFile(sdMain.FileName);
end;

procedure TForm1.miFileExitClick(Sender: TObject);
begin
  Close;
end;

{РАБОТА С ЗАПИСЯМИ}

procedure TForm1.miAddClick(Sender: TObject);
var
  d1: Integer;
  DT: TDateTime;
  DormitoryRec: dormitory;
  f: file of dormitory;
begin
  if not TryStrToInt(Trim(eBlock.Text), d1) then
  begin
    ShowMessage('Поле "Блок" должно содержать число!');
    Exit;
  end;

  if not TryStrToDate(eData.Text, DT) then
  begin
    ShowMessage('Неверная дата заселения! Формат: дд.мм.гггг');
    Exit;
  end;

  if not TryStrToDate(eDataV.Text, DT) then
  begin
    ShowMessage('Неверная дата выселения! Формат: дд.мм.гггг');
    Exit;
  end;

  DormitoryRec.FIO    := Trim(eFIO.Text);
  DormitoryRec.Room   := Trim(eRoom.Text);
  DormitoryRec.Block  := Trim(eBlock.Text);
  DormitoryRec.Data  := Trim(eData.Text);
  DormitoryRec.DataV := Trim(eDataV.Text);

  if CurrentFile <> '' then
  begin
    try
      AssignFile(f, CurrentFile);
      Reset(f);
      Seek(f, FileSize(f)); // Становимся в самый конец файла
      Write(f, DormitoryRec);
      CloseFile(f);
    except
      ShowMessage('Ошибка при добавлении записи в файл!');
      Exit;
    end;
  end;

  ShowAllRows;
  SG.RowCount := SG.RowCount + 1;
  SG.Cells[0, SG.RowCount-1] := DormitoryRec.FIO;
  SG.Cells[1, SG.RowCount-1] := DormitoryRec.Room;
  SG.Cells[2, SG.RowCount-1] := DormitoryRec.Block;
  SG.Cells[3, SG.RowCount-1] := DormitoryRec.Data;
  SG.Cells[4, SG.RowCount-1] := DormitoryRec.DataV;

  IsChanged := True;
  miClearClick(Sender);
end;

procedure TForm1.miEditClick(Sender: TObject);
var
  DormitoryRec: dormitory;
  RowIndex: Integer;
  f: file of dormitory;
  d1: Integer;
  DT: TDateTime;
begin
  // Проверяем, выбрана ли строка
  if (SG.Row <= 0) or (SG.RowHeights[SG.Row] = 0) then
  begin
    ShowMessage('Выберите запись в таблице двойным кликом для редактирования!');
    Exit;
  end;

  // Проверяем заполнение полей
  if (Trim(eFIO.Text) = '') or
     (Trim(eRoom.Text) = '') or
     (Trim(eBlock.Text) = '') or
     (Trim(eData.Text) = '') or
     (Trim(eDataV.Text) = '') then
  begin
    ShowMessage('Поля ввода не могут быть пустыми!');
    Exit;
  end;

  // Проверяем номер блока
  if not TryStrToInt(Trim(eBlock.Text), d1) then
  begin
    ShowMessage('Поле "Блок" должно содержать число!');
    Exit;
  end;

  // Проверяем дату заселения
  if not TryStrToDate(Trim(eData.Text), DT) then
  begin
    ShowMessage('Неверная дата заселения! Формат: дд.мм.гггг');
    Exit;
  end;

  // Проверяем дату выселения
  if not TryStrToDate(Trim(eDataV.Text), DT) then
  begin
    ShowMessage('Неверная дата выселения! Формат: дд.мм.гггг');
    Exit;
  end;

  // Заполняем запись
  DormitoryRec.FIO   := Trim(eFIO.Text);
  DormitoryRec.Room  := Trim(eRoom.Text);
  DormitoryRec.Block  := Trim(eBlock.Text);
  DormitoryRec.Data  := Trim(eData.Text);
  DormitoryRec.DataV := Trim(eDataV.Text);

  // Индекс записи в файле
  RowIndex := SG.Row - 1;

  // Обновляем запись в файле
  if CurrentFile <> '' then
  begin
    try
      AssignFile(f, CurrentFile);
      Reset(f);
      Seek(f, RowIndex);
      Write(f, DormitoryRec);
      CloseFile(f);
    except
      ShowMessage('Ошибка доступа к файлу при сохранении изменений!');
      Exit;
    end;
  end;

  // Обновляем таблицу
  SG.Cells[0, SG.Row] := DormitoryRec.FIO;
  SG.Cells[1, SG.Row] := DormitoryRec.Room;
  SG.Cells[2, SG.Row] := DormitoryRec.Block;
  SG.Cells[3, SG.Row] := DormitoryRec.Data;
  SG.Cells[4, SG.Row] := DormitoryRec.DataV;

  IsChanged := True;

  ShowMessage('Запись успешно изменена.');

  miClearClick(Sender);
end;

procedure TForm1.miDelClick(Sender: TObject);
begin
  if SG.RowCount <= 1 then
  begin
    ShowMessage('Таблица пуста, удалять нечего!');
    Exit;
  end;

  if (SG.Row < 1) or (SG.RowHeights[SG.Row] = 0) then
  begin
    ShowMessage('Попытка удалить запись без выбора! Кликните по строке с товаром.');
    Exit;
  end;

  if MessageDlg('Подтверждение удаления',
                'Вы действительно хотите удалить запись "' + SG.Cells[1, SG.Row] + '"?',
                mtConfirmation, [mbYes, mbNo], 0) = mrYes then
  begin
    SG.DeleteRow(SG.Row);
    IsChanged := True;
    miClearClick(Sender);

    if CurrentFile <> '' then
      SaveToFile(CurrentFile)
    else
      SaveToFile(ExtractFilePath(ParamStr(0)) + 'stock.dat');

    ShowMessage('Запись успешно удалена.');
  end;
end;

{ РАБОЧИЙ ПЕРЕНОС ЗАПИСИ ПРИ ДВОЙНОМ КЛИКЕ }
procedure TForm1.SGDblClick(Sender: TObject);
begin
  if (SG.RowCount > 1) and (SG.Row >= 1) and (SG.RowHeights[SG.Row] > 0) then
  begin
    eFIO.Text    := SG.Cells[0, SG.Row];
    eRoom.Text   := SG.Cells[1, SG.Row];
    eBlock.Text  := SG.Cells[2, SG.Row];
    eData.Text  := SG.Cells[3, SG.Row];
    eDataV.Text := SG.Cells[4, SG.Row];
  end;
end;

{ ПОИСК, ФИЛЬТР, СОРТИРОВКА }

procedure TForm1.miSearchClick(Sender: TObject);
var
  i: Integer;
  SearchText: string;
  Found: Boolean;
begin
  SearchText := Trim(eFIO.Text);
  if SearchText = '' then SearchText := Trim(eRoom.Text);

  if SearchText = '' then
  begin
    ShowMessage('Для поиска введите Артикул или Наименование в поля слева!');
    ShowAllRows;
    Exit;
  end;

  Found := False;
  for i := 1 to SG.RowCount - 1 do
  begin
    if (Pos(AnsiUpperCase(SearchText), AnsiUpperCase(SG.Cells[0, i])) > 0) or
       (Pos(AnsiUpperCase(SearchText), AnsiUpperCase(SG.Cells[1, i])) > 0) then
    begin
      SG.RowHeights[i] := SG.DefaultRowHeight;
      Found := True;
    end
    else
      SG.RowHeights[i] := 0;
  end;

  if not Found then
  begin
    ShowMessage('Ничего не найдено!');
    ShowAllRows;
  end;
end;

procedure TForm1.miClearClick(Sender: TObject);
begin
  eFIO.Clear; eRoom.Clear; eBlock.Clear; eData.Clear; eDataV.Clear;
  ShowAllRows;
end;

procedure TForm1.miSortAscClick(Sender: TObject);
var
  i, j, col: Integer;
begin
  ShowAllRows;

  if SG.RowCount <= 2 then Exit;

  if eFIO.Focused then col := 0
  else if eRoom.Focused then col := 1
  else if eBlock.Focused then col := 2
  else if eData.Focused then col := 3
  else if eDataV.Focused then col := 4
  else col := 1;

  for i := 1 to SG.RowCount - 2 do
  begin
    for j := 1 to SG.RowCount - i - 1 do
    begin
      if AnsiCompareText(SG.Cells[col, j], SG.Cells[col, j + 1]) > 0 then
      begin
        SwapGridRows(j, j + 1);
      end;
    end;
  end;
  IsChanged := True;
end;

procedure TForm1.miSortDescClick(Sender: TObject);
var
  i, j, col: Integer;
begin
  ShowAllRows;

  if SG.RowCount <= 2 then Exit;

  if eFIO.Focused then col := 0
  else if eRoom.Focused then col := 1
  else if eBlock.Focused then col := 2
  else if eData.Focused then col := 3
  else if eDataV.Focused then col := 4
  else col := 1;

  for i := 1 to SG.RowCount - 2 do
  begin
    for j := 1 to SG.RowCount - i - 1 do
    begin
      if AnsiCompareText(SG.Cells[col, j], SG.Cells[col, j + 1]) < 0 then
      begin
        SwapGridRows(j, j + 1);
      end;
    end;
  end;
  IsChanged := True;
end;

procedure TForm1.FormClose(Sender: TObject; var CloseAction: TCloseAction);
begin
  if IsChanged and (SG.RowCount > 1) then
  begin
    if MessageDlg('Несохраненные изменения',
                  'В системе остались несохраненные изменения! Сохранить их перед выходом?',
                  mtConfirmation, [mbYes, mbNo], 0) = mrYes then
    begin
      miSaveClick(Sender);
    end;
  end;

  if (SG.RowCount > 1) and (CurrentFile <> '') and (not IsChanged) then
    SaveToFile(CurrentFile);
end;

end.
