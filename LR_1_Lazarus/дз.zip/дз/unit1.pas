unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, Buttons;

type

  { TForm1 }

  TForm1 = class(TForm)
    BitBtn1: TBitBtn;
    Button1: TButton;
    Edit1: TEdit;
    Edit2: TEdit;
    Edit3: TEdit;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Memo1: TMemo;
    procedure BitBtn1Click(Sender: TObject);
    procedure Button1Click(Sender: TObject);
  private

  public

  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

{ TForm1 }

procedure TForm1.BitBtn1Click(Sender: TObject);
begin
  Close;
end;

procedure TForm1.Button1Click(Sender: TObject);
  var
  a, b, h, x, y: Double;
begin

  Memo1.Clear;

  try

    a := StrToFloat(Edit1.Text);
    b := StrToFloat(Edit2.Text);
    h := StrToFloat(Edit3.Text);

    if h <= 0 then
    begin
      ShowMessage('Ошибка: Шаг h должен быть больше нуля!');
      Exit;
    end;

    if a > b then
    begin
      ShowMessage('Ошибка: Начало отрезка (a) должно быть меньше конца (b)!');
      Exit;
    end;

    x := a;

    while x <= (b + 0.00001) do
    begin
      y := sqr(x);

      Memo1.Lines.Add('При x = ' + FloatToStrF(x, ffFixed, 8, 2) +
                      '  y = ' + FloatToStrF(y, ffFixed, 8, 4));

      x := x + h;
    end;

  except

    on E: EConvertError do
      ShowMessage('Ошибка ввода! Пожалуйста, введите корректные числа.');
  end;
end;

end.

