unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, Buttons;

type

  { TForm1 }

  TForm1 = class(TForm)
    BitBtn1: TBitBtn;
    Button1: TButton;
    Edit1: TEdit;
    Edit2: TEdit;
    Edit3: TEdit;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Memo1: TMemo;
    procedure BitBtn1Click(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure Edit2Change(Sender: TObject);
    procedure Label3Click(Sender: TObject);
  private

  public

  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

{ TForm1 }

procedure TForm1.Label3Click(Sender: TObject);
begin

end;

procedure TForm1.Edit2Change(Sender: TObject);
begin

end;

procedure TForm1.BitBtn1Click(Sender: TObject);
begin
  Close;
end;

procedure TForm1.Button1Click(Sender: TObject);
  var
  a, b, t, f: Double;
begin
  try
    a := StrToFloat(Edit1.Text);
    b := StrToFloat(Edit2.Text);
    t := StrToFloat(Edit3.Text);

    f := Exp(-b * t) * Sin(a * t + b) - Sqrt(Abs(b * t + a));

    Memo1.Lines.Add(Format('Введено: a=%.2f; b=%.2f; t=%.2f', [a, b, t]));
    Memo1.Lines.Add('Результат f = ' + FloatToStrF(f, ffFixed, 8, 4));
  except
    on E: EConvertError do
      ShowMessage('Пожалуйста, введите корректные числа для Задачи . Дробная часть отделяется запятой (или точкой в зависимости от настроек ОС).');
  end;
end;

end.

