unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, Buttons, Math;

type

  { TForm1 }

  TForm1 = class(TForm)
    BitBtn1: TBitBtn;
    ButtonCalc: TButton;
    EditC: TEdit;
    EditAlpha: TEdit;
    Label1: TLabel;
    Label2: TLabel;
    Memo1: TMemo;
    procedure BitBtn1Click(Sender: TObject);
    procedure ButtonCalcClick(Sender: TObject);
  private

  public

  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

{ TForm1 }

procedure TForm1.BitBtn1Click(Sender: TObject);
begin
  Close;
end;

procedure TForm1.ButtonCalcClick(Sender: TObject);
  var
  c, alpha_deg, alpha_rad, side_a, S: Double;
begin
  // Очищаем Memo перед новым расчетом (по желанию)
  // Memo1.Clear;

  try
    // 1. Считываем данные из полей ввода
    c := StrToFloat(EditC.Text);
    alpha_deg := StrToFloat(EditAlpha.Text);

    // 2. Проверка: может ли такой треугольник существовать?
    // Угол при основании должен быть острым (от 0 до 90 градусов)
    if (alpha_deg <= 0) or (alpha_deg >= 90) then
    begin
      ShowMessage('Ошибка: Угол при основании должен быть от 0 до 90 градусов!');
      Exit; // Прерываем выполнение
    end;

    if c <= 0 then
    begin
      ShowMessage('Ошибка: Основание должно быть больше нуля!');
      Exit;
    end;

    // 3. Математические вычисления
    // Переводим градусы в радианы, так как функции Cos и Tan работают только с ними
    alpha_rad := DegToRad(alpha_deg);

    // Формула боковой стороны: a = c / (2 * cos(alpha))
    side_a := c / (2 * Cos(alpha_rad));

    // Формула площади: S = (c^2 * tan(alpha)) / 4
    S := (Sqr(c) * Tan(alpha_rad)) / 4;

    // 4. Вывод красивого результата в Memo
    Memo1.Lines.Add('=== Расчет треугольника ===');
    Memo1.Lines.Add('Входные данные:');
    Memo1.Lines.Add('  Основание (c) = ' + FloatToStr(c));
    Memo1.Lines.Add('  Угол (alpha) = ' + FloatToStr(alpha_deg) + '°');
    Memo1.Lines.Add('Результаты:');
    // Используем FloatToStrF для округления до 3 знаков после запятой
    Memo1.Lines.Add('  Боковая сторона (a) = ' + FloatToStrF(side_a, ffFixed, 8, 3));
    Memo1.Lines.Add('  Площадь (S) = ' + FloatToStrF(S, ffFixed, 8, 3));
    Memo1.Lines.Add('---------------------------');

  except
    // Если пользователь ввел буквы вместо чисел
    on E: EConvertError do
      ShowMessage('Ошибка: вводите только числа. Для дробей используйте запятую.');
  end;
end;

end.

