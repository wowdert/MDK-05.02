unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, Buttons, Math;

type

  { TForm1 }

  TForm1 = class(TForm)
    BitBtn1: TBitBtn;
    ButtonCalc: TButton;
    EditC: TEdit;
    EditAlpha: TEdit;
    Label1: TLabel;
    Label2: TLabel;
    Memo1: TMemo;
    procedure BitBtn1Click(Sender: TObject);
    procedure ButtonCalcClick(Sender: TObject);
  private

  public

  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

{ TForm1 }

procedure TForm1.BitBtn1Click(Sender: TObject);
begin
  Close;
end;

procedure TForm1.ButtonCalcClick(Sender: TObject);
  var
  c, alpha_deg, alpha_rad, side_a, S: Double;
begin

  try

    c := StrToFloat(EditC.Text);
    alpha_deg := StrToFloat(EditAlpha.Text);

    if (alpha_deg <= 0) or (alpha_deg >= 90) then
    begin
      ShowMessage('Ошибка: Угол при основании должен быть от 0 до 90 градусов!');
      Exit;
    end;

    if c <= 0 then
    begin
      ShowMessage('Ошибка: Основание должно быть больше нуля!');
      Exit;
    end;

    alpha_rad := DegToRad(alpha_deg);

    side_a := c / (2 * Cos(alpha_rad));

    S := (Sqr(c) * Tan(alpha_rad)) / 4;

    Memo1.Lines.Add('=== Расчет треугольника ===');
    Memo1.Lines.Add('Входные данные:');
    Memo1.Lines.Add('  Основание (c) = ' + FloatToStr(c));
    Memo1.Lines.Add('  Угол (alpha) = ' + FloatToStr(alpha_deg) + '°');
    Memo1.Lines.Add('Результаты:');
    Memo1.Lines.Add('  Боковая сторона (a) = ' + FloatToStrF(side_a, ffFixed, 8, 3));
    Memo1.Lines.Add('  Площадь (S) = ' + FloatToStrF(S, ffFixed, 8, 3));
    Memo1.Lines.Add('---------------------------');

  except
    on E: EConvertError do
      ShowMessage('Ошибка: вводите только числа. Для дробей используйте запятую.');
  end;
end;

end.

